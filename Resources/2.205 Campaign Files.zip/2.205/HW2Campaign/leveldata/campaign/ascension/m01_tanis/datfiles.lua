Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m01_tanis.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS01A_M01_Tanis.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS01B_M01_Tanis.dat",
	}
}