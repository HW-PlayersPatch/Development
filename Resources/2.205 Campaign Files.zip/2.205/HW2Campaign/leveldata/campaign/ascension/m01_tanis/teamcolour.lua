-- [Player Index] = {{Teamcolour R, G, B}, {Stripecolour R, G, B}, "BadgeFileName.tga"),

teamcolours = 
{
[0] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga",{.365,.553,.667},"data:/effect/trails/hgn_trail_clr.tga"}, -- player
[1] =	{{ 1, .494, 0},	{ 1, .494, 0},	"DATA:Badges/Hiigaran.tga",{.365,.553,.667},"data:/effect/trails/hgn_trail_clr.tga"}, -- tanis, mothership, outer stations
[2] =	{{.752,.694,.556},	{1,1,1},			"DATA:Badges/Hiigaran.tga",{.365,.553,.667},"data:/effect/trails/hgn_trail_clr.tga"}, -- tanis defence fleet
[3] =	{{.900,.900,.900},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga",{.921,.75,.419},"data:/effect/trails/vgr_trail_clr.tga"}, -- vaygr attackers --{{.900,.900,.900},	{.450,0,0},	"badges/vaygr.tga"}, -- vaygr attackers
}