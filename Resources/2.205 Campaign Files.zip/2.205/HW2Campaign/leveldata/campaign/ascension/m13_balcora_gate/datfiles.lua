Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m13_balcora_gate.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS13_M13_Balcora_Gate.dat",
	},
}