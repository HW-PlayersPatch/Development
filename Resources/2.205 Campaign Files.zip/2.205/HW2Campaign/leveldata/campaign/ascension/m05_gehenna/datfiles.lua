Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m05_gehenna.dat",
	},
}