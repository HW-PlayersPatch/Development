Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m12_rescue.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS12B_M12_Rescue.dat",
	},
}