-- [Player Index] = {{Teamcolour R, G, B}, {Stripecolour R, G, B}, "BadgeFileName.tga"),

teamcolours = 
{
[0] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga",{.365,.553,.667},"data:/effect/trails/hgn_trail_clr.tga"}, -- player
[1] =	{{0.047,0.047,0.047},	{.561,0,.043},	"DATA:Badges/Vaygr.tga"}, -- el33t vaygr?
[2] =	{{.900,.900,.900},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga",{.921,.75,.419},"data:/effect/trails/vgr_trail_clr.tga"}, -- vaygr attackers
}