Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m04_outergeh.dat",
	},
}