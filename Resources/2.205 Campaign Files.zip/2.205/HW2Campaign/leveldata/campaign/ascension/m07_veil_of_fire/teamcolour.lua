-- [Player Index] = {{Teamcolour R, G, B}, {Stripecolour R, G, B}, "BadgeFileName.tga"),

teamcolours = 
{
[0] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga"}, -- player
[1] =	{{.900,.900,.900},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga",{.921,.75,.419},"data:/effect/trails/vgr_trail_clr.tga"}, -- vaygr attackers
[2] =	{{.0,.925,.521},	{.100,.100,.100},	"DATA:Badges/Hiigaran.tga"}, -- movers
}