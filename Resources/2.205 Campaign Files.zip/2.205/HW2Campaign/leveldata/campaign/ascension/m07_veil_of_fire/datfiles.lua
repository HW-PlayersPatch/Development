Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m07_veil_of_fire.dat",
	},
}