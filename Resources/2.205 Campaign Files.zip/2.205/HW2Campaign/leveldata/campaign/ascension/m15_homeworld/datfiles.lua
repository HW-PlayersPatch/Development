Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m15_homeworld.dat",
	},
}