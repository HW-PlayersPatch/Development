Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m02_hiigara.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS02A_M02_Hiigara.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS02B_M02_Hiigara.dat",
	},
}