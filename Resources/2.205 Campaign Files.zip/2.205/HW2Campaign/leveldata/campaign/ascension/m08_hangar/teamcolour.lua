-- [Player Index] = {{Teamcolour R, G, B}, {Stripecolour R, G, B}, "BadgeFileName.tga"),

teamcolours = 
{
[0] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga"}, -- player
[1] =	{{.0,.925,.521},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga"}, -- Keeper!
}