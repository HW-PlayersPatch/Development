Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m08_hangar.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS08_M08_Hangar.dat",
	},
}