-- reinforcement options for this player

-- Note: this reinforcement "fleet" is a dummy fleet used to get a count for how many Attack Droids 
--       the Keeper should build during the mission

Reinforcements = 
{
    {
        Type = "Hgn_Scout",
        Weight = 1,
    },
}
