-- reinforcement options for this player

Reinforcements = 
{
}
