Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m10_bentusi.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS10_M10_Bentusi.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/M07_Veil_Of_Fire.dat",
	},
}