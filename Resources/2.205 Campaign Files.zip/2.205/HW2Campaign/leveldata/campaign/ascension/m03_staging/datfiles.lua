Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m03_staging.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS03_M03_Staging.dat",
	},
}