Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m11_final_core.dat",
	},
}