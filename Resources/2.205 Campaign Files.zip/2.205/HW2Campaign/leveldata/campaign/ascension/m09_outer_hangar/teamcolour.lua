-- [Player Index] = {{Teamcolour R, G, B}, {Stripecolour R, G, B}, "BadgeFileName.tga"),

teamcolours = 
{
[0] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga"}, -- player
[1] =	{{.900,.900,.900},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga",{.921,.75,.419},"data:/effect/trails/vgr_trail_clr.tga"}, -- vaygr attackers
[2] =	{{.900,.900,.900},	{.100,.100,.100},	"DATA:Badges/Vaygr.tga",{.921,.75,.419},"data:/effect/trails/vgr_trail_clr.tga"}, -- vaygr attackers
[3] =	{{0.047,0.047,0.047},	{.561,0,.043},	"DATA:Badges/Vaygr.tga"}, -- el33t vaygr?
[4] =	{{0,0,0},		{1,1,1},		"DATA:Badges/Soban.tga",{.365,.553,.667},"data:/effect/trails/hgn_trail_clr.tga"}, -- Talorn Soban (gets a different stripe colour)
[5] =	{{.365,.553,.667},	{.800,.800,.800},	"DATA:Badges/Hiigaran.tga"}, -- player
}