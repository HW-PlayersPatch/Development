Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m09_outer_hangar.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS09A_M09_Outer_Hangar.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS09B_M09_Outer_Hangar.dat",
	},
}