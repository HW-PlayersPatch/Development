-- reinforcement options for this player

Reinforcements = 
{
    {
        Type = "Vgr_WeaponPlatform_gun",
        Weight = -1,
    },
    {
        Type = "Vgr_WeaponPlatform_missile",
        Weight = -1,
    },
    {
        Type = "Vgr_AssaultFrigate",
        Weight = 1,
    },
    {
        Type = "Vgr_HeavyMissileFrigate",
        Weight = 3,
    },
    {
        Type = "Vgr_BattleCruiser",
        Weight = 1,
    },
    {
        Type = "Vgr_LaserCorvette",
        Weight = 2,
    },
    {
        Type = "Vgr_MissileCorvette",
        Weight = 2,
    },
}
