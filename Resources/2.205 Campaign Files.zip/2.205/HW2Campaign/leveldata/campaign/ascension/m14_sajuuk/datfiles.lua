Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m14_sajuuk.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/m02_hiigara.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS14A_M14_Sajuuk.dat",
	},
	{
		name = "locale:leveldata/campaign/ascension/NIS14B_M14_Sajuuk.dat",
	},
}