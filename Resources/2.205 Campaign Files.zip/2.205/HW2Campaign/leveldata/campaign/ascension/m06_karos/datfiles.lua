Dictionaries =
{
	{
		name = "locale:leveldata/campaign/ascension/m06_karos.dat",
	},
}