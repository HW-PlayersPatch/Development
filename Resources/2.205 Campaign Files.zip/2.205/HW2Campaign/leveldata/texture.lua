-- see Data:texture.lua.help for help

outputFormat =
{
	version = 1,

	textureFormat = TF_DXT1_NOALPHA,
	mipmap = 0,
}
