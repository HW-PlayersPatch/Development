-- Kushan

String_Properties_Priority = 1.0

String_Properties = {
	path_build = [[data:scripts/races/kushan/scripts/sp_build.lua]],
	path_research = [[data:scripts/races/kushan/scripts/sp_research.lua]], 
}