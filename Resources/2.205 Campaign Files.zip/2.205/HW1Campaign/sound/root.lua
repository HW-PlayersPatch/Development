-- This file is generated automatically by the Relic Audio Tool

version = 3

priority = 99
compression = 0
volume = 1.000000
volumeRand = -1.000000
frequency = -1
frequencyRand = 0
destination = 1
patch = 1
numChannels = 1
maxPolyphony = 1
loopStart = 0
loopEnd = -1
startOffset = 0
loopCount = 1
loopCountRand = -1
type3D = 0
doppler = 0.000000
coneMin = 0.000000
coneMax = 0.000000
envelope = {
  {
    distance = 0.000000,
    volume = 1.000000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 500.000000,
    volume = 0.900000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 1000.000000,
    volume = 0.600000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 2000.000000,
    volume = 0.250000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 4000.000000,
    volume = 0.000000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
}
randSampContainer = 0

