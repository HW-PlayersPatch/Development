-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Tai_AssaultFrigate",
        Weight = 1,
    },
    {
        Type = "Tai_IonCannonFrigate",
        Weight = 1,
    },
    {
        Type = "Tai_HeavyCorvette",
        Weight = 1,
    },
    {
        Type = "Tai_Defender",
        Weight = 1,
    },
    {
        Type = "Tai_HeavyCorvette",
        Weight = 1,
    },
    {
        Type = "Tai_IonCannonFrigate",
        Weight = 1,
    },
    {
        Type = "Tai_Scout",
        Weight = 1,
    },
    {
        Type = "Tai_SupportFrigate",
        Weight = 1,
    },
}

