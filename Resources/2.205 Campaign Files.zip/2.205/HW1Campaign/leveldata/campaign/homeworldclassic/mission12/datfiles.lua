Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission12LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission12.dat",
    },
    --Optionally add other dat files (for NISs)
}
