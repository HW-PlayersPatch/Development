Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission04LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission04.dat",
    },
    {
		name = "locale:leveldata/campaign/HomeworldClassic/n03r1.dat",
	}

}
