-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Tur_IonArrayFrigate",
        Weight = 1,
    },
    {
        Type = "Tur_Fighter",
        Weight = 1,
    },
    {
        Type = "Tur_StandardCorvette",
        Weight = 1,
    },
}

