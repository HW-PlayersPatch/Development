Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission15LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission15.dat",
    },
    --Optionally add other dat files (for NISs)
}
