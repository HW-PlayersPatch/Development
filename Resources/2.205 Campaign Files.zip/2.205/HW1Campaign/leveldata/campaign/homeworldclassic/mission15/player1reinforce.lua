-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Tai_Destroyer",
        Weight = 1,
    },
    {
        Type = "Tai_AssaultFrigate",
        Weight = 1,
    },
    {
        Type = "Tai_Interceptor",
        Weight = 1,
    },
    {
        Type = "Tai_Defender",
        Weight = 1,
    },
    {
        Type = "Tai_MultiGunCorvette",
        Weight = 1,
    },
    {
        Type = "Tai_HeavyCorvette",
        Weight = 1,
    },
}

