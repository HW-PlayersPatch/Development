Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission16LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission16.dat",
    },
    --Optionally add other dat files (for NISs)
}
