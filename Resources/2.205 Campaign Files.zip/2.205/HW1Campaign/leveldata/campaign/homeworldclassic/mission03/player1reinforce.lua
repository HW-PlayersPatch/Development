-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Tai_AssaultFrigate",
        Weight = 1,
    },
}

