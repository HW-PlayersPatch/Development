Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission03LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission03.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/n04.dat",
    },
    --Optionally add other dat files (for NISs)
}
