Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission06LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission06.dat",
    },
    --Optionally add other dat files (for NISs)
}
