Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission05LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission05.dat",
    },
    --Optionally add other dat files (for NISs)
}
