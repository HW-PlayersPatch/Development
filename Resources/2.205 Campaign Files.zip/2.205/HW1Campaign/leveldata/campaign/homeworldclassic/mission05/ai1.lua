
aitrace("CPU: loading DUMMY CPU PLAYER (Scripted enemy)")


function oninit()
    aitrace("CPU:  DUMMY oninit()")
end

function doai()
end

