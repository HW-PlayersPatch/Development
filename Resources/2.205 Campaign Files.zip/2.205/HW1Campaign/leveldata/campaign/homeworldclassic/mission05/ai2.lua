
aitrace("CPU: loading DUMMY CPU PLAYER (Player Ally)")


function oninit()
    aitrace("CPU:  DUMMY oninit()")
end

function doai()
end

