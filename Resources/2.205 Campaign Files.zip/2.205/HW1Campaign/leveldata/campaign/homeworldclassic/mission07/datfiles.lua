Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission07LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission07.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/n05r1.dat",
    },
    --Optionally add other dat files (for NISs)
}
