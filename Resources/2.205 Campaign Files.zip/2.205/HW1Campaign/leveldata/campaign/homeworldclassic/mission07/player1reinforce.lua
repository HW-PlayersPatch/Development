-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Kad_FuelPod",
        Weight = 1,
    },
    {
        Type = "Kad_Swarmer",
        Weight = 1,
    },
    {
        Type = "Kad_AdvancedSwarmer",
        Weight = 1,
    },
    {
        Type = "Kad_MultiBeamFrigate",
        Weight = 1,
    },
}

