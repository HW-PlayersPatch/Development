Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission13LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission13.dat",
    },
    --Optionally add other dat files (for NISs)
}
