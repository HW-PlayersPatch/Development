Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission02LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission02.dat",
    },
    --Optionally add other dat files (for NISs)
}
