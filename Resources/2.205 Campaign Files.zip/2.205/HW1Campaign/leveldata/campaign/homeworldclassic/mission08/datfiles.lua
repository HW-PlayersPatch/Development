Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission08LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission08.dat",
    },
    --Optionally add other dat files (for NISs)
}
