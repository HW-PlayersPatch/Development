-- reinforcement options for this player

Reinforcements =
{
    {
        Type = "Tai_AttackBomber",
        Weight = 1,
    },
    {
        Type = "Tai_HeavyCorvette",
        Weight = 1,
    },
    {
        Type = "Tai_Interceptor",
        Weight = 1,
    },
    {
        Type = "Tai_AssaultFrigate",
        Weight = 1,
    },
}

