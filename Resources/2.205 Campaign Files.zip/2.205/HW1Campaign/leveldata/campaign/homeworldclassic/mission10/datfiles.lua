Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission10LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission10.dat",
    },
    --Optionally add other dat files (for NISs)
}
