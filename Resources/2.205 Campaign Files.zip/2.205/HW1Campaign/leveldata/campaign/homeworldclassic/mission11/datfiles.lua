Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission11LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission11.dat",
    },
	{
		name = "locale:leveldata/campaign/HomeworldClassic/n08r1a.dat",
	},

    --Optionally add other dat files (for NISs)
}
