Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission09LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission09.dat",
    },
    --Optionally add other dat files (for NISs)
}
