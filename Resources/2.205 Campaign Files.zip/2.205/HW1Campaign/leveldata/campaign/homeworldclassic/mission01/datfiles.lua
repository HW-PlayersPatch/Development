Dictionaries =
{
	{
		name = "locale:leveldata/campaign/HomeworldClassic/Mission01LSTRINGs.dat",
	},
	{
		name = "locale:leveldata/campaign/HomeworldClassic/Mission01.dat",
	},
	{
		name = "locale:leveldata/campaign/HomeworldClassic/n01r1.dat",
	},
	{
		name = "locale:leveldata/campaign/HomeworldClassic/n01r2.dat",
	}
}