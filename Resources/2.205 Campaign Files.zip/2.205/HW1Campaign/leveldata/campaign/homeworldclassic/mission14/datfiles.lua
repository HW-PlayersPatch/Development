Dictionaries =
{
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission14LSTRINGs.dat",
    },
    {
        name = "locale:leveldata/campaign/HomeworldClassic/Mission14.dat",
    },
    --Optionally add other dat files (for NISs)
}
